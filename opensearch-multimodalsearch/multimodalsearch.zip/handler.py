'''
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
'''

from collections import namedtuple
from datetime import datetime, timedelta
from dateutil import tz, parser
import itertools
import json
import os
import time
import uuid
import requests
from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
from requests_aws4auth import AWS4Auth
from datetime import datetime
import boto3


# Lambda Interval Settings (seconds)
LAMBDA_INTERVAL=60

################################################################################
# Environment

DOMAIN_ENDPOINT =   os.environ['DOMAIN_ENDPOINT'] #"search-opensearchservi-rimlzstyyeih-3zru5p2nxizobaym45e5inuayq.us-west-2.es.amazonaws.com" 
REGION = os.environ['REGION'] #'us-west-2'#
SAGEMAKER_MODEL_ID = os.environ['SAGEMAKER_MODEL_ID'] #'P_vh7YsBNIVobUP3w7RJ' #
BEDROCK_TEXT_MODEL_ID = os.environ['BEDROCK_TEXT_MODEL_ID'] 
BEDROCK_MULTIMODAL_MODEL_ID = os.environ['BEDROCK_MULTIMODAL_MODEL_ID'] 

current_date_time = (datetime.now()).isoformat()
today_ = datetime.today().strftime('%Y-%m-%d')


# #session=boto3.Session(
        
# aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
# aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'],
# aws_session_token=os.environ['AWS_SESSION_TOKEN']
# #    )


#awsauth = AWS4Auth(aws_access_key_id, aws_secret_access_key, REGION, 'es', session_token=aws_session_token)

credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, REGION, 'es', session_token=credentials.token)


# Lambda handler
def handler(event, context):
  #{'inputs': '{"CombineType": "arithmetic_mean", "weight": 0.5, "text": "wine glass", "NormType": "min_max", "searchType": "Keyword Search"}', 'session_id': ''}input_ = 
  print("------")
  print(event)
  print("------")
  print(event['body'])
  
  input_ = json.loads((json.loads(event['body']))["inputs"])
  print("*********")
  print(input_)
  
  norm_type = input_["NormType"]
  combine_type = input_["CombineType"]
  semantic_weight = input_["weight"]
  search_type = input_["searchType"]
  model_type = input_["modelType"]
  query = input_["text"]
  img = input_["image"]
  
  k_ = input_["K"]
  image_upload = input_["imageUpload"]
  
  if(search_type == 'Keyword Search'):
    semantic_weight = 0.0
  if(search_type == 'Vector Search'):
    semantic_weight = 1.0
  if('sagemaker' in model_type.lower()):
    index_name = 'sagemaker-search-index'
    model_id = SAGEMAKER_MODEL_ID
  else:
    index_name = 'bedrock_text-search-index'
    model_id = BEDROCK_TEXT_MODEL_ID
  if(search_type == 'Multi-modal Search'):
    index_name = 'bedrock-multimodal-search-index'
    model_id = BEDROCK_MULTIMODAL_MODEL_ID
  
    
  
    
  
  
  path = "_search/pipeline/hybrid-search-pipeline" 
  host = 'https://'+DOMAIN_ENDPOINT+'/'
  url = host + path
  
  payload = {
    "description": "Post processor for hybrid search",
    "phase_results_processors": [
      {
        "normalization-processor": {
          "normalization": {
            "technique": norm_type
          },
          "combination": {
            "technique": combine_type,
            "parameters": {
              "weights": [1-semantic_weight,semantic_weight]
            }
          }
        }
      }
    ]
  }
  
  headers = {"Content-Type": "application/json"}
  
  if(search_type != 'Multi-modal Search'):
    r = requests.put(url, auth=awsauth, json=payload, headers=headers)
    print(r.status_code)
    print(r.text)
    
    
  
    path = index_name+"/_search?search_pipeline=hybrid-search-pipeline" 
    
    url = host + path
    
    payload = {
      "_source": {
        "exclude": [
          "caption_embedding"
        ]
      },
      "query": {
        "hybrid": {
          "queries": [
            {
              "match": {
                "caption": {
                  "query": query
                }
              }
            },
            {
              "neural": {
                "caption_embedding": {
                  "query_text": query,
                  "model_id": model_id,
                  "k": k_
                }
              }
            }
          ]
        }
      },"size":k_
    }
    r = requests.get(url, auth=awsauth, json=payload, headers=headers)
    print(r.status_code)
    print(r.text)
    
  else:
  
    path = index_name+"/_search"
    url = host + path
    
    
    payload = {
    "size": k_,
       "_source": {
      "exclude": [
        "image_binary","vector_embedding"
      ]
    },
    "query": {
      "neural": {
        "vector_embedding": {
          
          "model_id": model_id,
          "k": k_
          }
        }
        }
      }
      
    if(image_upload == 'yes' and query == ""):
      payload["query"]["neural"]["vector_embedding"]["query_image"] =  img
    if(image_upload == 'no' and query != ""):
      payload["query"]["neural"]["vector_embedding"]["query_text"] =  query
    if(image_upload == 'yes' and query != ""):
      payload["query"]["neural"]["vector_embedding"]["query_image"] =  img
      payload["query"]["neural"]["vector_embedding"]["query_text"] =  query
          
    
    r = requests.get(url, auth=awsauth, json=payload, headers=headers)
    print(r.status_code)
    print(r.text)
    print(payload)
    
  return r.text
  
